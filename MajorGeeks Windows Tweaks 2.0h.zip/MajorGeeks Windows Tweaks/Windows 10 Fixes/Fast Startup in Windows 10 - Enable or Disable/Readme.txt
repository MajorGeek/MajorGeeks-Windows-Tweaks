How to Turn Fast Startup On or Off in Windows 10 by MajorGeeks.Com

https://www.majorgeeks.com/content/page/how_to_turn_fast_startup_on_or_off_in_windows_10.html

Enclosed are both registry files and batch files. To turn Fast Startup on or off, Hibernate must be disabled.

The bat files will disable Hibernate AND add the registry entry.

If you're unsure if Hibernate is disabled, use the bat files.

If you're sure Hibernate is disabled, you can run just the registry files.
