Here's a handy batch file script for Windows users who want to customize their scroll bars. 

This is a really simple script that allows you to adjust the width and height of the scroll bars on your system with just a few keystrokes—literally.

Unzip the file and run the enclosed .bat file. You can enter your desired height and width for the scroll bars. The script will our script apply the changes directly to your system settings via the Windows Registry. 

After confirming your changes, a quick log-off is required to apply the changes.

The default value is 17.  We recommend using something between 5 and 32 px.

This script is perfect for those who want to enhance their visual and navigational experience on their PC. Give it a try and see how a small tweak can make a big difference!

Thank you to our buddy at [1]https://www.majorgeeks.com/files/details/alomware_toolbox.html[2]Alomware[3] for getting this one actually to work!