Welcome to a massive collection of registry, PowerShell, and batch file tweaks from MajorGeeks.Com

All tweaks are categorized to help you find what you want. 
Most folders contain a "MajorGeeks Tutorial Link.html" which links to the tutorial, or download page. That allows you to:

Understand the tweak better
Get directions to make the changes manually
Get directions when there are multiple file options

-------------------------------------------------------------------------------------------------------------
If we helped you out you could buy our shirts, stickers, hoodies, coffee mugs, phone cases, socks, even yoga pants:
https://teespring.com/stores/majorgeeks

Check out MajorGeeks. Quality software and tutorials since 2000:
https://www.majorgeeks.com/

Check out all these tweaks individually at:
https://www.majorgeeks.com/mg/sortname/majorgeeks_registry_batch_file_tweaks.html

Check out our YouTube channel:
https://www.youtube.com/user/majorgeeks